import React, {ChangeEvent, KeyboardEvent} from "react";
import s from "./Greeting.module.css";

type GreetingPropsType = {
    name: string
    setNameCallback: (e:ChangeEvent<HTMLInputElement>) => void
    addUser: (name: string) => void
    error: string
    totalUsers: number
    onKeyPressInput: (e:KeyboardEvent<HTMLInputElement>) => void
}


const Greeting: React.FC<GreetingPropsType> = ({name, setNameCallback, addUser, error, totalUsers, onKeyPressInput}) => {
    const inputClass = {
        padding: "10px",
        fontSize: "18px"
    }

    return (
        <div className={s.mainField}>
            <div> <input value={name} onChange={setNameCallback} style={inputClass} className={s.input} onKeyPress={onKeyPressInput}/> </div>
            <div> {error ? <span className={s.error}>{error}</span> : ''} </div>
            <div> <button onClick={() => {addUser(name)}} className={s.button}>add</button> </div>
            <div> <span className={s.span}>{totalUsers}</span> </div>
        </div>
    );
}

export default Greeting;
